class InvalidNumberOfArgumentsException(Exception):
    def __init__(self):
        super(InvalidNumberOfArgumentsException, self).__init__()